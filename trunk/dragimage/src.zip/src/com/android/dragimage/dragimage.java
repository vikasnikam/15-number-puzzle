package com.android.dragimage;



import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.Window;

public class dragimage extends Activity {
	
   private playareaview playView;
   private Context mContext;

   @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = getApplicationContext();
        playView = new playareaview(this);
        setContentView(playView);
    }
   @Override
   public void onDestroy() {
	   super.onDestroy();
	   playView.unregisterReceiver();
      	System.gc();
    	System.runFinalization();
    	System.gc();
   }
}