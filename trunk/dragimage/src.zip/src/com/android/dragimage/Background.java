package com.android.dragimage;

import java.util.ArrayList;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Bitmap.Config;
import android.view.Display;
import android.view.WindowManager;

public class Background {
	 private Bitmap img; // the image of the ball
	 private int width = 0; // the x coordinate at the canvas
	 private int height = 0; // the y coordinate at the canvas
	 private int ROWS = 4; // the x coordinate at the canvas
	 private int COLUMNS = 4; // the y coordinate at the canvas
	 private int xoffsetLandscape = 15;
	 private int xoffsetportrait = 10;
	 private int cellSizeX = 0;
	 private int cellSizeY = 0;
	 private int reqPlaywidth = 0;
	 private boolean isPortrait;
	 private boolean isUpdateNumberCellsPositions;
	 private Context mContext;
	 private Paint mPaint;
	 private playareaview mParent;
	 private int lineGap = 3;
	 private numbers[] numbers;

	 public class numbersCellPosition
		{
			public int x;
			public int y;
		}
	 private ArrayList<numbersCellPosition > numbersPos = new ArrayList<numbersCellPosition>();
		
	 private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
	        public void onReceive(Context context, Intent intent) {
	            String action = intent.getAction();
	            if (Intent.ACTION_CONFIGURATION_CHANGED.equals(action)) {
	            	updateBackground();
	            }
	        }
	    };
	    
	 Background(Context context,Paint paint,playareaview parent,numbers[] aNum)
	 {
		 mContext = context;
		 mPaint = paint;
		 mParent = parent;
		 numbers = aNum;
		IntentFilter filter = new IntentFilter();
		filter.addAction(Intent.ACTION_CONFIGURATION_CHANGED);
		context.registerReceiver(mBroadcastReceiver, filter);
		updateBackground();
		System.out.println("NUmbers count is"+aNum.length);
	 }
	 public void unregisterReceiver()
	 {
		 mContext.unregisterReceiver(mBroadcastReceiver); 
	 }
	 public void updateBackground()
	 {
			Display display = ((WindowManager)mContext.getSystemService(mContext.WINDOW_SERVICE)).getDefaultDisplay();  
			  
			width = display.getWidth();  
			height = display.getHeight(); 
			reqPlaywidth = display.getWidth();
			
			if(width > height)
			{
				 reqPlaywidth = display.getHeight();
				 isPortrait = false;
			}
			else
			{
				 isPortrait = true;;
			}
			mParent.invalidate();
			isUpdateNumberCellsPositions = true;
	    }
		public Bitmap getBackgroundImage()
		{
			Bitmap bitmap;
			Bitmap mbitmap;
			bitmap = Bitmap.createBitmap(width,height, Config.ARGB_8888);
			Canvas drawcanvas = new Canvas(bitmap);
			if(isPortrait)
			mbitmap = BitmapFactory.decodeResource(mContext.getResources(), com.android.dragimage.R.drawable.background);
			else
			mbitmap = BitmapFactory.decodeResource(mContext.getResources(), com.android.dragimage.R.drawable.landscape);
            drawcanvas.drawBitmap(mbitmap,0,0,mPaint);
            
            mbitmap = BitmapFactory.decodeResource(mContext.getResources(), com.android.dragimage.R.drawable.square);
            
			int yOffset;
			int xOffset ;
			
			if(isPortrait)
			{
			cellSizeX = (reqPlaywidth - ((3*lineGap)+xoffsetportrait ))/ 4;				
			yOffset = ((height * 18 )/100);
			xOffset = xoffsetportrait;
			}
			else
			{
			cellSizeX = (reqPlaywidth - ((3*lineGap)+xoffsetLandscape ))/ 4;				
			yOffset = ((height * 5 )/100);
			xOffset=xoffsetLandscape;
			}
			
			int rightOffset=cellSizeX;
			int bottomOffset=yOffset+cellSizeX;
			
			Rect source;
			Rect destination = new Rect();
		
			for( int i=0;i<ROWS;i++)
			{
				for(int j=0;j<COLUMNS;j++)
				{
				destination.top = yOffset;
				destination.left = xOffset;
				destination.right = rightOffset;
				destination.bottom = bottomOffset;

				if(	isUpdateNumberCellsPositions)
				{
					numbersCellPosition obj = new numbersCellPosition();
					obj.x = destination.left;
					obj.y = destination.top;
					numbersPos.add(obj);
				}
				
				drawcanvas.drawBitmap(mbitmap,null,destination,mPaint);
				xOffset = xOffset + cellSizeX+lineGap;
				rightOffset = rightOffset+cellSizeX+lineGap;
				}

				if(isPortrait)
					 xOffset = xoffsetportrait;
				 else
				 xOffset=xoffsetLandscape;
				 		
				rightOffset = cellSizeX;
				yOffset = yOffset + cellSizeX+lineGap;
				bottomOffset = bottomOffset + cellSizeX;

			}
			isUpdateNumberCellsPositions = false;
			
			 mbitmap = BitmapFactory.decodeResource(mContext.getResources(), com.android.dragimage.R.drawable.number1);
				if(isPortrait)
				{
				yOffset = ((height * 18 )/100);
				xOffset =xoffsetportrait;
				}
				else
				{
				yOffset = ((height * 5 )/100);			
				xOffset=xoffsetLandscape;
				}
				
			 rightOffset=cellSizeX;
			 bottomOffset=yOffset+cellSizeX;
			 int numbersCount=0;

			for( int i=0;i<ROWS;i++)
				{
				 for(int j=0;j<COLUMNS;j++)
					{
						if(numbersCount < 15)
						{
						if(numbers[numbersCount].getX()!= 0 && numbers[numbersCount].getY()!= 0)
						{
							destination.top = numbers[numbersCount].getY();
							destination.left = numbers[numbersCount].getX();					
						}
						else
						{
							numbers[numbersCount].setY(yOffset);
							numbers[numbersCount].setX(xOffset) ;
							destination.top = yOffset;
							destination.left = xOffset;
							
						}
						destination.right = rightOffset;
						destination.bottom = bottomOffset;

							drawcanvas.drawBitmap(numbers[numbersCount].getBitmap(),null,destination,mPaint);
							numbersCount++;
						}
						

						xOffset = xOffset + cellSizeX+lineGap;
						rightOffset = rightOffset+cellSizeX+lineGap;
						
						
					}
				
				 if(isPortrait)
				 xOffset = xoffsetportrait;
				 else
				 {
				 xOffset=xoffsetLandscape;

				 }		
						rightOffset = cellSizeX;
						yOffset = yOffset + cellSizeX+lineGap;
						bottomOffset = bottomOffset + cellSizeX;
				}
			
			return bitmap;
		}
		public boolean isGameFinished()
		{
			boolean isGameFinish = true;
			for(int i =0;i<numbers.length;i++)
			{
					if(numbers[i].getX() == numbersPos.get(i).x && numbers[i].getY() == numbersPos.get(i).y)
				{
					System.out.println("NUmbers match"+numbers[i].getX()+":"+numbers[i].getY()+":"+numbersPos.get(i).x+":"+numbersPos.get(i).y);
				}
				else
				{
					System.out.println("NUmbers miss match match"+numbers[i].getX()+":"+numbers[i].getY()+":"+numbersPos.get(i).x+":"+numbersPos.get(i).y);
					isGameFinish = false;
					break;
				}
			} 
			return isGameFinish;
		}
}
