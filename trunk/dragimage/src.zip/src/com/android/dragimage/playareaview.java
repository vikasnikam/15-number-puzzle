package com.android.dragimage;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

public class playareaview extends View
{

		int positionX = 5;
		int positionY = 15;
		int imageX = 0;
		int imageY = 0;
		int imageWidth = 50;
		int imageHeight = 50;
		Boolean imagemove = false;
		Context mContext;
		Paint mPaint;
		Background mBackground;
		private numbers[] numbers = new numbers[15]; // array that holds the numbers
		private int numberID=0;
		
		playareaview(Context context)
		{
			super(context);
			mContext = context;
			
			mPaint = new Paint();
			mPaint.setTextSize(16);
			// set Color- blue
		    mPaint.setColor(0xFF0000FF);
		    mPaint.setTextSize(16);
		 
		    mBackground = new Background(context,mPaint,this,numbers);
		    for(int i=0;i<15;i++)
		    	numbers[i] =  new numbers(context,i);
		    
		}
		public void unregisterReceiver()
		{
			mBackground.unregisterReceiver();
		}
		  @Override
		    public boolean onTouchEvent(MotionEvent event)
		    {
                positionX = (int)event.getX();
	            positionY = (int)event.getY();
	          System.out.println("X & Y"+positionX+":"+positionY);
	            switch(event.getAction())
	            {
		            case MotionEvent.ACTION_DOWN: {
		            	if(positionX > imageX && positionX < imageWidth && positionY >imageY && positionY <imageHeight)
		            	{
		            		System.out.println("Click inside the image");
		            	    imagemove= true;
		            	    
		            	}	
		            	System.out.println(mBackground.isGameFinished());
		            }
		            case MotionEvent.ACTION_MOVE: {
		            	if(imagemove == true)
		            	{
		            		imageX = positionX;
		            		imageY= positionY;
		            	System.out.println("Action move");
		            	
		            	}
		            }
		            case MotionEvent.ACTION_UP: {
		            	System.out.println("POinter up");
		            	imagemove = false;
		            }
	            }

	            
	            invalidate();
	            return true;
		    }
		@Override
		public void onDraw(Canvas canvas)
		{
			Bitmap bitmap = mBackground.getBackgroundImage();
			canvas.drawText("Mani", positionX, positionY, mPaint);
			canvas.drawBitmap(bitmap, imageX,imageY, mPaint);
			bitmap.recycle();
		}

}
